﻿
namespace Criptografia
{
    partial class projeto
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox_Dados = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_Visualizar = new System.Windows.Forms.Button();
            this.textoCrip = new System.Windows.Forms.TextBox();
            this.btn_Descriptografar = new System.Windows.Forms.Button();
            this.lbl_Texto = new System.Windows.Forms.Label();
            this.Texto = new System.Windows.Forms.TextBox();
            this.btn_Criptografar = new System.Windows.Forms.Button();
            this.DataAtual = new System.Windows.Forms.Button();
            this.Dia = new System.Windows.Forms.TextBox();
            this.Mes = new System.Windows.Forms.TextBox();
            this.Ano = new System.Windows.Forms.TextBox();
            this.Min = new System.Windows.Forms.TextBox();
            this.Hora = new System.Windows.Forms.TextBox();
            this.Sec = new System.Windows.Forms.TextBox();
            this.lbl_Sec = new System.Windows.Forms.Label();
            this.lbl_Mes = new System.Windows.Forms.Label();
            this.lbl_Ano = new System.Windows.Forms.Label();
            this.lbl_Dia = new System.Windows.Forms.Label();
            this.lbl_Hora = new System.Windows.Forms.Label();
            this.lbl_Min = new System.Windows.Forms.Label();
            this.Arquivo = new System.Windows.Forms.Button();
            this.b1 = new System.Windows.Forms.TextBox();
            this.b2 = new System.Windows.Forms.TextBox();
            this.b3 = new System.Windows.Forms.TextBox();
            this.b4 = new System.Windows.Forms.TextBox();
            this.b7 = new System.Windows.Forms.TextBox();
            this.b6 = new System.Windows.Forms.TextBox();
            this.b9 = new System.Windows.Forms.TextBox();
            this.b8 = new System.Windows.Forms.TextBox();
            this.b5 = new System.Windows.Forms.TextBox();
            this.o5 = new System.Windows.Forms.TextBox();
            this.o8 = new System.Windows.Forms.TextBox();
            this.o9 = new System.Windows.Forms.TextBox();
            this.o6 = new System.Windows.Forms.TextBox();
            this.o7 = new System.Windows.Forms.TextBox();
            this.o4 = new System.Windows.Forms.TextBox();
            this.o3 = new System.Windows.Forms.TextBox();
            this.o2 = new System.Windows.Forms.TextBox();
            this.o1 = new System.Windows.Forms.TextBox();
            this.y5 = new System.Windows.Forms.TextBox();
            this.y8 = new System.Windows.Forms.TextBox();
            this.y9 = new System.Windows.Forms.TextBox();
            this.y6 = new System.Windows.Forms.TextBox();
            this.y7 = new System.Windows.Forms.TextBox();
            this.y4 = new System.Windows.Forms.TextBox();
            this.y3 = new System.Windows.Forms.TextBox();
            this.y2 = new System.Windows.Forms.TextBox();
            this.y1 = new System.Windows.Forms.TextBox();
            this.g5 = new System.Windows.Forms.TextBox();
            this.g8 = new System.Windows.Forms.TextBox();
            this.g9 = new System.Windows.Forms.TextBox();
            this.g6 = new System.Windows.Forms.TextBox();
            this.g7 = new System.Windows.Forms.TextBox();
            this.g4 = new System.Windows.Forms.TextBox();
            this.g3 = new System.Windows.Forms.TextBox();
            this.g2 = new System.Windows.Forms.TextBox();
            this.g1 = new System.Windows.Forms.TextBox();
            this.r5 = new System.Windows.Forms.TextBox();
            this.r8 = new System.Windows.Forms.TextBox();
            this.r9 = new System.Windows.Forms.TextBox();
            this.r6 = new System.Windows.Forms.TextBox();
            this.r7 = new System.Windows.Forms.TextBox();
            this.r4 = new System.Windows.Forms.TextBox();
            this.r3 = new System.Windows.Forms.TextBox();
            this.r2 = new System.Windows.Forms.TextBox();
            this.r1 = new System.Windows.Forms.TextBox();
            this.w5 = new System.Windows.Forms.TextBox();
            this.w8 = new System.Windows.Forms.TextBox();
            this.w9 = new System.Windows.Forms.TextBox();
            this.w6 = new System.Windows.Forms.TextBox();
            this.w7 = new System.Windows.Forms.TextBox();
            this.w4 = new System.Windows.Forms.TextBox();
            this.w3 = new System.Windows.Forms.TextBox();
            this.w2 = new System.Windows.Forms.TextBox();
            this.w1 = new System.Windows.Forms.TextBox();
            this.groupBox_Cubo = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.ArquivoCrip = new System.Windows.Forms.Button();
            this.GerArq = new System.Windows.Forms.Button();
            this.ArquivoTXT = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox_Dados.SuspendLayout();
            this.groupBox_Cubo.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox_Dados
            // 
            this.groupBox_Dados.Controls.Add(this.label1);
            this.groupBox_Dados.Controls.Add(this.btn_Visualizar);
            this.groupBox_Dados.Controls.Add(this.textoCrip);
            this.groupBox_Dados.Controls.Add(this.btn_Descriptografar);
            this.groupBox_Dados.Controls.Add(this.lbl_Texto);
            this.groupBox_Dados.Controls.Add(this.Texto);
            this.groupBox_Dados.Controls.Add(this.btn_Criptografar);
            this.groupBox_Dados.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_Dados.Location = new System.Drawing.Point(44, 308);
            this.groupBox_Dados.Name = "groupBox_Dados";
            this.groupBox_Dados.Size = new System.Drawing.Size(330, 366);
            this.groupBox_Dados.TabIndex = 0;
            this.groupBox_Dados.TabStop = false;
            this.groupBox_Dados.Text = "Frase";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(44, 157);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(242, 22);
            this.label1.TabIndex = 20;
            this.label1.Text = "FRASE CRIPTOGRAFADO:";
            // 
            // btn_Visualizar
            // 
            this.btn_Visualizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Visualizar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Visualizar.Location = new System.Drawing.Point(106, 311);
            this.btn_Visualizar.Name = "btn_Visualizar";
            this.btn_Visualizar.Size = new System.Drawing.Size(118, 32);
            this.btn_Visualizar.TabIndex = 17;
            this.btn_Visualizar.Text = "Visualizar";
            this.btn_Visualizar.UseVisualStyleBackColor = true;
            this.btn_Visualizar.Click += new System.EventHandler(this.btn_Visualizar_Click);
            // 
            // textoCrip
            // 
            this.textoCrip.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textoCrip.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textoCrip.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textoCrip.Location = new System.Drawing.Point(45, 183);
            this.textoCrip.Multiline = true;
            this.textoCrip.Name = "textoCrip";
            this.textoCrip.Size = new System.Drawing.Size(240, 74);
            this.textoCrip.TabIndex = 15;
            // 
            // btn_Descriptografar
            // 
            this.btn_Descriptografar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Descriptografar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Descriptografar.Location = new System.Drawing.Point(167, 270);
            this.btn_Descriptografar.Name = "btn_Descriptografar";
            this.btn_Descriptografar.Size = new System.Drawing.Size(118, 32);
            this.btn_Descriptografar.TabIndex = 18;
            this.btn_Descriptografar.Text = "Descriptografar";
            this.btn_Descriptografar.UseVisualStyleBackColor = true;
            this.btn_Descriptografar.Click += new System.EventHandler(this.btn_Descriptografar_Click);
            // 
            // lbl_Texto
            // 
            this.lbl_Texto.AutoSize = true;
            this.lbl_Texto.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Texto.Location = new System.Drawing.Point(87, 45);
            this.lbl_Texto.Name = "lbl_Texto";
            this.lbl_Texto.Size = new System.Drawing.Size(175, 22);
            this.lbl_Texto.TabIndex = 16;
            this.lbl_Texto.Text = "DIGITE SUA FRASE:";
            // 
            // Texto
            // 
            this.Texto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Texto.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.Texto.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Texto.Location = new System.Drawing.Point(45, 69);
            this.Texto.Multiline = true;
            this.Texto.Name = "Texto";
            this.Texto.Size = new System.Drawing.Size(240, 74);
            this.Texto.TabIndex = 13;
            this.Texto.Tag = "";
            // 
            // btn_Criptografar
            // 
            this.btn_Criptografar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Criptografar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Criptografar.Location = new System.Drawing.Point(45, 270);
            this.btn_Criptografar.Name = "btn_Criptografar";
            this.btn_Criptografar.Size = new System.Drawing.Size(118, 32);
            this.btn_Criptografar.TabIndex = 14;
            this.btn_Criptografar.Text = "Criptografar";
            this.btn_Criptografar.UseVisualStyleBackColor = true;
            this.btn_Criptografar.Click += new System.EventHandler(this.btn_Criptografar_Click);
            // 
            // DataAtual
            // 
            this.DataAtual.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DataAtual.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DataAtual.Location = new System.Drawing.Point(105, 163);
            this.DataAtual.Name = "DataAtual";
            this.DataAtual.Size = new System.Drawing.Size(118, 32);
            this.DataAtual.TabIndex = 56;
            this.DataAtual.Text = "Tempo Real";
            this.DataAtual.UseVisualStyleBackColor = true;
            this.DataAtual.Click += new System.EventHandler(this.button2_Click);
            // 
            // Dia
            // 
            this.Dia.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Dia.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dia.Location = new System.Drawing.Point(212, 62);
            this.Dia.Name = "Dia";
            this.Dia.Size = new System.Drawing.Size(42, 24);
            this.Dia.TabIndex = 4;
            this.Dia.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Dia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Ano_KeyPress);
            // 
            // Mes
            // 
            this.Mes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Mes.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mes.Location = new System.Drawing.Point(143, 62);
            this.Mes.Name = "Mes";
            this.Mes.Size = new System.Drawing.Size(42, 24);
            this.Mes.TabIndex = 2;
            this.Mes.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Mes.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Ano_KeyPress);
            // 
            // Ano
            // 
            this.Ano.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Ano.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ano.Location = new System.Drawing.Point(74, 62);
            this.Ano.Name = "Ano";
            this.Ano.Size = new System.Drawing.Size(42, 24);
            this.Ano.TabIndex = 0;
            this.Ano.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Ano.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Ano_KeyPress);
            // 
            // Min
            // 
            this.Min.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Min.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Min.Location = new System.Drawing.Point(143, 123);
            this.Min.Name = "Min";
            this.Min.Size = new System.Drawing.Size(42, 24);
            this.Min.TabIndex = 8;
            this.Min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Min.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Ano_KeyPress);
            // 
            // Hora
            // 
            this.Hora.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Hora.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Hora.Location = new System.Drawing.Point(74, 123);
            this.Hora.Name = "Hora";
            this.Hora.Size = new System.Drawing.Size(42, 24);
            this.Hora.TabIndex = 6;
            this.Hora.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Hora.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Ano_KeyPress);
            // 
            // Sec
            // 
            this.Sec.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Sec.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sec.Location = new System.Drawing.Point(212, 123);
            this.Sec.Name = "Sec";
            this.Sec.Size = new System.Drawing.Size(42, 24);
            this.Sec.TabIndex = 10;
            this.Sec.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Sec.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Ano_KeyPress);
            // 
            // lbl_Sec
            // 
            this.lbl_Sec.AutoSize = true;
            this.lbl_Sec.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Sec.Location = new System.Drawing.Point(201, 103);
            this.lbl_Sec.Name = "lbl_Sec";
            this.lbl_Sec.Size = new System.Drawing.Size(67, 18);
            this.lbl_Sec.TabIndex = 11;
            this.lbl_Sec.Text = "Segundo";
            // 
            // lbl_Mes
            // 
            this.lbl_Mes.AutoSize = true;
            this.lbl_Mes.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mes.Location = new System.Drawing.Point(145, 42);
            this.lbl_Mes.Name = "lbl_Mes";
            this.lbl_Mes.Size = new System.Drawing.Size(37, 18);
            this.lbl_Mes.TabIndex = 3;
            this.lbl_Mes.Text = "Mês";
            // 
            // lbl_Ano
            // 
            this.lbl_Ano.AutoSize = true;
            this.lbl_Ano.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Ano.Location = new System.Drawing.Point(78, 42);
            this.lbl_Ano.Name = "lbl_Ano";
            this.lbl_Ano.Size = new System.Drawing.Size(34, 18);
            this.lbl_Ano.TabIndex = 1;
            this.lbl_Ano.Text = "Ano";
            // 
            // lbl_Dia
            // 
            this.lbl_Dia.AutoSize = true;
            this.lbl_Dia.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Dia.Location = new System.Drawing.Point(218, 43);
            this.lbl_Dia.Name = "lbl_Dia";
            this.lbl_Dia.Size = new System.Drawing.Size(30, 18);
            this.lbl_Dia.TabIndex = 5;
            this.lbl_Dia.Text = "Dia";
            // 
            // lbl_Hora
            // 
            this.lbl_Hora.AutoSize = true;
            this.lbl_Hora.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Hora.Location = new System.Drawing.Point(75, 103);
            this.lbl_Hora.Name = "lbl_Hora";
            this.lbl_Hora.Size = new System.Drawing.Size(41, 18);
            this.lbl_Hora.TabIndex = 7;
            this.lbl_Hora.Text = "Hora";
            // 
            // lbl_Min
            // 
            this.lbl_Min.AutoSize = true;
            this.lbl_Min.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Min.Location = new System.Drawing.Point(139, 103);
            this.lbl_Min.Name = "lbl_Min";
            this.lbl_Min.Size = new System.Drawing.Size(53, 18);
            this.lbl_Min.TabIndex = 9;
            this.lbl_Min.Text = "Minuto";
            // 
            // Arquivo
            // 
            this.Arquivo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Arquivo.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Arquivo.Location = new System.Drawing.Point(18, 519);
            this.Arquivo.Name = "Arquivo";
            this.Arquivo.Size = new System.Drawing.Size(140, 32);
            this.Arquivo.TabIndex = 55;
            this.Arquivo.Text = "Arquivo";
            this.Arquivo.UseVisualStyleBackColor = true;
            this.Arquivo.Click += new System.EventHandler(this.button1_Click);
            // 
            // b1
            // 
            this.b1.BackColor = System.Drawing.Color.Blue;
            this.b1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.b1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b1.Location = new System.Drawing.Point(35, 119);
            this.b1.Multiline = true;
            this.b1.Name = "b1";
            this.b1.ReadOnly = true;
            this.b1.Size = new System.Drawing.Size(35, 34);
            this.b1.TabIndex = 1;
            this.b1.TabStop = false;
            this.b1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // b2
            // 
            this.b2.BackColor = System.Drawing.Color.Blue;
            this.b2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.b2.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b2.Location = new System.Drawing.Point(76, 119);
            this.b2.Multiline = true;
            this.b2.Name = "b2";
            this.b2.ReadOnly = true;
            this.b2.Size = new System.Drawing.Size(35, 34);
            this.b2.TabIndex = 2;
            this.b2.TabStop = false;
            this.b2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // b3
            // 
            this.b3.BackColor = System.Drawing.Color.Blue;
            this.b3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b3.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.b3.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b3.Location = new System.Drawing.Point(117, 119);
            this.b3.Multiline = true;
            this.b3.Name = "b3";
            this.b3.ReadOnly = true;
            this.b3.Size = new System.Drawing.Size(35, 34);
            this.b3.TabIndex = 3;
            this.b3.TabStop = false;
            this.b3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // b4
            // 
            this.b4.BackColor = System.Drawing.Color.Blue;
            this.b4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b4.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.b4.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b4.Location = new System.Drawing.Point(35, 159);
            this.b4.Multiline = true;
            this.b4.Name = "b4";
            this.b4.ReadOnly = true;
            this.b4.Size = new System.Drawing.Size(35, 34);
            this.b4.TabIndex = 4;
            this.b4.TabStop = false;
            this.b4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // b7
            // 
            this.b7.BackColor = System.Drawing.Color.Blue;
            this.b7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b7.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.b7.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b7.Location = new System.Drawing.Point(35, 199);
            this.b7.Multiline = true;
            this.b7.Name = "b7";
            this.b7.ReadOnly = true;
            this.b7.Size = new System.Drawing.Size(35, 34);
            this.b7.TabIndex = 5;
            this.b7.TabStop = false;
            this.b7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // b6
            // 
            this.b6.BackColor = System.Drawing.Color.Blue;
            this.b6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b6.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.b6.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b6.Location = new System.Drawing.Point(117, 159);
            this.b6.Multiline = true;
            this.b6.Name = "b6";
            this.b6.ReadOnly = true;
            this.b6.Size = new System.Drawing.Size(35, 34);
            this.b6.TabIndex = 6;
            this.b6.TabStop = false;
            this.b6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // b9
            // 
            this.b9.BackColor = System.Drawing.Color.Blue;
            this.b9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b9.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.b9.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b9.Location = new System.Drawing.Point(117, 199);
            this.b9.Multiline = true;
            this.b9.Name = "b9";
            this.b9.ReadOnly = true;
            this.b9.Size = new System.Drawing.Size(35, 34);
            this.b9.TabIndex = 7;
            this.b9.TabStop = false;
            this.b9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // b8
            // 
            this.b8.BackColor = System.Drawing.Color.Blue;
            this.b8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b8.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.b8.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b8.Location = new System.Drawing.Point(76, 199);
            this.b8.Multiline = true;
            this.b8.Name = "b8";
            this.b8.ReadOnly = true;
            this.b8.Size = new System.Drawing.Size(35, 34);
            this.b8.TabIndex = 8;
            this.b8.TabStop = false;
            this.b8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // b5
            // 
            this.b5.BackColor = System.Drawing.Color.Blue;
            this.b5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.b5.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.b5.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b5.Location = new System.Drawing.Point(76, 159);
            this.b5.Multiline = true;
            this.b5.Name = "b5";
            this.b5.ReadOnly = true;
            this.b5.Size = new System.Drawing.Size(35, 34);
            this.b5.TabIndex = 9;
            this.b5.TabStop = false;
            this.b5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // o5
            // 
            this.o5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.o5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.o5.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.o5.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.o5.Location = new System.Drawing.Point(203, 159);
            this.o5.Multiline = true;
            this.o5.Name = "o5";
            this.o5.ReadOnly = true;
            this.o5.Size = new System.Drawing.Size(35, 34);
            this.o5.TabIndex = 18;
            this.o5.TabStop = false;
            this.o5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // o8
            // 
            this.o8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.o8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.o8.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.o8.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.o8.Location = new System.Drawing.Point(203, 199);
            this.o8.Multiline = true;
            this.o8.Name = "o8";
            this.o8.ReadOnly = true;
            this.o8.Size = new System.Drawing.Size(35, 34);
            this.o8.TabIndex = 17;
            this.o8.TabStop = false;
            this.o8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // o9
            // 
            this.o9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.o9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.o9.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.o9.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.o9.Location = new System.Drawing.Point(244, 199);
            this.o9.Multiline = true;
            this.o9.Name = "o9";
            this.o9.ReadOnly = true;
            this.o9.Size = new System.Drawing.Size(35, 34);
            this.o9.TabIndex = 16;
            this.o9.TabStop = false;
            this.o9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // o6
            // 
            this.o6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.o6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.o6.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.o6.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.o6.Location = new System.Drawing.Point(244, 159);
            this.o6.Multiline = true;
            this.o6.Name = "o6";
            this.o6.ReadOnly = true;
            this.o6.Size = new System.Drawing.Size(35, 34);
            this.o6.TabIndex = 15;
            this.o6.TabStop = false;
            this.o6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // o7
            // 
            this.o7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.o7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.o7.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.o7.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.o7.Location = new System.Drawing.Point(162, 199);
            this.o7.Multiline = true;
            this.o7.Name = "o7";
            this.o7.ReadOnly = true;
            this.o7.Size = new System.Drawing.Size(35, 34);
            this.o7.TabIndex = 14;
            this.o7.TabStop = false;
            this.o7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // o4
            // 
            this.o4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.o4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.o4.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.o4.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.o4.Location = new System.Drawing.Point(162, 159);
            this.o4.Multiline = true;
            this.o4.Name = "o4";
            this.o4.ReadOnly = true;
            this.o4.Size = new System.Drawing.Size(35, 34);
            this.o4.TabIndex = 13;
            this.o4.TabStop = false;
            this.o4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // o3
            // 
            this.o3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.o3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.o3.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.o3.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.o3.Location = new System.Drawing.Point(244, 119);
            this.o3.Multiline = true;
            this.o3.Name = "o3";
            this.o3.ReadOnly = true;
            this.o3.Size = new System.Drawing.Size(35, 34);
            this.o3.TabIndex = 12;
            this.o3.TabStop = false;
            this.o3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // o2
            // 
            this.o2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.o2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.o2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.o2.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.o2.Location = new System.Drawing.Point(203, 119);
            this.o2.Multiline = true;
            this.o2.Name = "o2";
            this.o2.ReadOnly = true;
            this.o2.Size = new System.Drawing.Size(35, 34);
            this.o2.TabIndex = 11;
            this.o2.TabStop = false;
            this.o2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // o1
            // 
            this.o1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.o1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.o1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.o1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.o1.Location = new System.Drawing.Point(162, 119);
            this.o1.Multiline = true;
            this.o1.Name = "o1";
            this.o1.ReadOnly = true;
            this.o1.Size = new System.Drawing.Size(35, 34);
            this.o1.TabIndex = 10;
            this.o1.TabStop = false;
            this.o1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // y5
            // 
            this.y5.BackColor = System.Drawing.Color.Yellow;
            this.y5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.y5.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.y5.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y5.Location = new System.Drawing.Point(203, 283);
            this.y5.Multiline = true;
            this.y5.Name = "y5";
            this.y5.ReadOnly = true;
            this.y5.Size = new System.Drawing.Size(35, 34);
            this.y5.TabIndex = 27;
            this.y5.TabStop = false;
            this.y5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // y8
            // 
            this.y8.BackColor = System.Drawing.Color.Yellow;
            this.y8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.y8.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.y8.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y8.Location = new System.Drawing.Point(203, 323);
            this.y8.Multiline = true;
            this.y8.Name = "y8";
            this.y8.ReadOnly = true;
            this.y8.Size = new System.Drawing.Size(35, 34);
            this.y8.TabIndex = 26;
            this.y8.TabStop = false;
            this.y8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // y9
            // 
            this.y9.BackColor = System.Drawing.Color.Yellow;
            this.y9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.y9.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.y9.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y9.Location = new System.Drawing.Point(244, 323);
            this.y9.Multiline = true;
            this.y9.Name = "y9";
            this.y9.ReadOnly = true;
            this.y9.Size = new System.Drawing.Size(35, 34);
            this.y9.TabIndex = 25;
            this.y9.TabStop = false;
            this.y9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // y6
            // 
            this.y6.BackColor = System.Drawing.Color.Yellow;
            this.y6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.y6.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.y6.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y6.Location = new System.Drawing.Point(244, 283);
            this.y6.Multiline = true;
            this.y6.Name = "y6";
            this.y6.ReadOnly = true;
            this.y6.Size = new System.Drawing.Size(35, 34);
            this.y6.TabIndex = 24;
            this.y6.TabStop = false;
            this.y6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // y7
            // 
            this.y7.BackColor = System.Drawing.Color.Yellow;
            this.y7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.y7.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.y7.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y7.Location = new System.Drawing.Point(162, 323);
            this.y7.Multiline = true;
            this.y7.Name = "y7";
            this.y7.ReadOnly = true;
            this.y7.Size = new System.Drawing.Size(35, 34);
            this.y7.TabIndex = 23;
            this.y7.TabStop = false;
            this.y7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // y4
            // 
            this.y4.BackColor = System.Drawing.Color.Yellow;
            this.y4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.y4.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.y4.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y4.Location = new System.Drawing.Point(162, 283);
            this.y4.Multiline = true;
            this.y4.Name = "y4";
            this.y4.ReadOnly = true;
            this.y4.Size = new System.Drawing.Size(35, 34);
            this.y4.TabIndex = 22;
            this.y4.TabStop = false;
            this.y4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // y3
            // 
            this.y3.BackColor = System.Drawing.Color.Yellow;
            this.y3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.y3.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.y3.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y3.Location = new System.Drawing.Point(244, 243);
            this.y3.Multiline = true;
            this.y3.Name = "y3";
            this.y3.ReadOnly = true;
            this.y3.Size = new System.Drawing.Size(35, 34);
            this.y3.TabIndex = 21;
            this.y3.TabStop = false;
            this.y3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // y2
            // 
            this.y2.BackColor = System.Drawing.Color.Yellow;
            this.y2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.y2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.y2.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y2.Location = new System.Drawing.Point(203, 243);
            this.y2.Multiline = true;
            this.y2.Name = "y2";
            this.y2.ReadOnly = true;
            this.y2.Size = new System.Drawing.Size(35, 34);
            this.y2.TabIndex = 20;
            this.y2.TabStop = false;
            this.y2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // y1
            // 
            this.y1.BackColor = System.Drawing.Color.Yellow;
            this.y1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.y1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.y1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y1.Location = new System.Drawing.Point(162, 243);
            this.y1.Multiline = true;
            this.y1.Name = "y1";
            this.y1.ReadOnly = true;
            this.y1.Size = new System.Drawing.Size(35, 34);
            this.y1.TabIndex = 19;
            this.y1.TabStop = false;
            this.y1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // g5
            // 
            this.g5.BackColor = System.Drawing.Color.Lime;
            this.g5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.g5.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.g5.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.g5.Location = new System.Drawing.Point(330, 283);
            this.g5.Multiline = true;
            this.g5.Name = "g5";
            this.g5.ReadOnly = true;
            this.g5.Size = new System.Drawing.Size(35, 34);
            this.g5.TabIndex = 36;
            this.g5.TabStop = false;
            this.g5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // g8
            // 
            this.g8.BackColor = System.Drawing.Color.Lime;
            this.g8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.g8.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.g8.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.g8.Location = new System.Drawing.Point(330, 323);
            this.g8.Multiline = true;
            this.g8.Name = "g8";
            this.g8.ReadOnly = true;
            this.g8.Size = new System.Drawing.Size(35, 34);
            this.g8.TabIndex = 35;
            this.g8.TabStop = false;
            this.g8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // g9
            // 
            this.g9.BackColor = System.Drawing.Color.Lime;
            this.g9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.g9.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.g9.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.g9.Location = new System.Drawing.Point(371, 323);
            this.g9.Multiline = true;
            this.g9.Name = "g9";
            this.g9.ReadOnly = true;
            this.g9.Size = new System.Drawing.Size(35, 34);
            this.g9.TabIndex = 34;
            this.g9.TabStop = false;
            this.g9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // g6
            // 
            this.g6.BackColor = System.Drawing.Color.Lime;
            this.g6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.g6.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.g6.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.g6.Location = new System.Drawing.Point(371, 283);
            this.g6.Multiline = true;
            this.g6.Name = "g6";
            this.g6.ReadOnly = true;
            this.g6.Size = new System.Drawing.Size(35, 34);
            this.g6.TabIndex = 33;
            this.g6.TabStop = false;
            this.g6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // g7
            // 
            this.g7.BackColor = System.Drawing.Color.Lime;
            this.g7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.g7.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.g7.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.g7.Location = new System.Drawing.Point(289, 323);
            this.g7.Multiline = true;
            this.g7.Name = "g7";
            this.g7.ReadOnly = true;
            this.g7.Size = new System.Drawing.Size(35, 34);
            this.g7.TabIndex = 32;
            this.g7.TabStop = false;
            this.g7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // g4
            // 
            this.g4.BackColor = System.Drawing.Color.Lime;
            this.g4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.g4.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.g4.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.g4.Location = new System.Drawing.Point(289, 283);
            this.g4.Multiline = true;
            this.g4.Name = "g4";
            this.g4.ReadOnly = true;
            this.g4.Size = new System.Drawing.Size(35, 34);
            this.g4.TabIndex = 31;
            this.g4.TabStop = false;
            this.g4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // g3
            // 
            this.g3.BackColor = System.Drawing.Color.Lime;
            this.g3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.g3.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.g3.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.g3.Location = new System.Drawing.Point(371, 243);
            this.g3.Multiline = true;
            this.g3.Name = "g3";
            this.g3.ReadOnly = true;
            this.g3.Size = new System.Drawing.Size(35, 34);
            this.g3.TabIndex = 30;
            this.g3.TabStop = false;
            this.g3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // g2
            // 
            this.g2.BackColor = System.Drawing.Color.Lime;
            this.g2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.g2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.g2.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.g2.Location = new System.Drawing.Point(330, 243);
            this.g2.Multiline = true;
            this.g2.Name = "g2";
            this.g2.ReadOnly = true;
            this.g2.Size = new System.Drawing.Size(35, 34);
            this.g2.TabIndex = 29;
            this.g2.TabStop = false;
            this.g2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // g1
            // 
            this.g1.BackColor = System.Drawing.Color.Lime;
            this.g1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.g1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.g1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.g1.Location = new System.Drawing.Point(289, 243);
            this.g1.Multiline = true;
            this.g1.Name = "g1";
            this.g1.ReadOnly = true;
            this.g1.Size = new System.Drawing.Size(35, 34);
            this.g1.TabIndex = 28;
            this.g1.TabStop = false;
            this.g1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // r5
            // 
            this.r5.BackColor = System.Drawing.Color.Red;
            this.r5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.r5.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.r5.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r5.Location = new System.Drawing.Point(330, 408);
            this.r5.Multiline = true;
            this.r5.Name = "r5";
            this.r5.ReadOnly = true;
            this.r5.Size = new System.Drawing.Size(35, 34);
            this.r5.TabIndex = 45;
            this.r5.TabStop = false;
            this.r5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // r8
            // 
            this.r8.BackColor = System.Drawing.Color.Red;
            this.r8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.r8.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.r8.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r8.Location = new System.Drawing.Point(330, 448);
            this.r8.Multiline = true;
            this.r8.Name = "r8";
            this.r8.ReadOnly = true;
            this.r8.Size = new System.Drawing.Size(35, 34);
            this.r8.TabIndex = 44;
            this.r8.TabStop = false;
            this.r8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // r9
            // 
            this.r9.BackColor = System.Drawing.Color.Red;
            this.r9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.r9.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.r9.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r9.Location = new System.Drawing.Point(371, 448);
            this.r9.Multiline = true;
            this.r9.Name = "r9";
            this.r9.ReadOnly = true;
            this.r9.Size = new System.Drawing.Size(35, 34);
            this.r9.TabIndex = 43;
            this.r9.TabStop = false;
            this.r9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // r6
            // 
            this.r6.BackColor = System.Drawing.Color.Red;
            this.r6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.r6.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.r6.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r6.Location = new System.Drawing.Point(371, 408);
            this.r6.Multiline = true;
            this.r6.Name = "r6";
            this.r6.ReadOnly = true;
            this.r6.Size = new System.Drawing.Size(35, 34);
            this.r6.TabIndex = 42;
            this.r6.TabStop = false;
            this.r6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // r7
            // 
            this.r7.BackColor = System.Drawing.Color.Red;
            this.r7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.r7.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.r7.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r7.Location = new System.Drawing.Point(289, 448);
            this.r7.Multiline = true;
            this.r7.Name = "r7";
            this.r7.ReadOnly = true;
            this.r7.Size = new System.Drawing.Size(35, 34);
            this.r7.TabIndex = 41;
            this.r7.TabStop = false;
            this.r7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // r4
            // 
            this.r4.BackColor = System.Drawing.Color.Red;
            this.r4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.r4.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.r4.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r4.Location = new System.Drawing.Point(289, 408);
            this.r4.Multiline = true;
            this.r4.Name = "r4";
            this.r4.ReadOnly = true;
            this.r4.Size = new System.Drawing.Size(35, 34);
            this.r4.TabIndex = 40;
            this.r4.TabStop = false;
            this.r4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // r3
            // 
            this.r3.BackColor = System.Drawing.Color.Red;
            this.r3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.r3.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.r3.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r3.Location = new System.Drawing.Point(371, 368);
            this.r3.Multiline = true;
            this.r3.Name = "r3";
            this.r3.ReadOnly = true;
            this.r3.Size = new System.Drawing.Size(35, 34);
            this.r3.TabIndex = 39;
            this.r3.TabStop = false;
            this.r3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // r2
            // 
            this.r2.BackColor = System.Drawing.Color.Red;
            this.r2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.r2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.r2.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r2.Location = new System.Drawing.Point(330, 368);
            this.r2.Multiline = true;
            this.r2.Name = "r2";
            this.r2.ReadOnly = true;
            this.r2.Size = new System.Drawing.Size(35, 34);
            this.r2.TabIndex = 38;
            this.r2.TabStop = false;
            this.r2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // r1
            // 
            this.r1.BackColor = System.Drawing.Color.Red;
            this.r1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.r1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.r1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r1.Location = new System.Drawing.Point(289, 368);
            this.r1.Multiline = true;
            this.r1.Name = "r1";
            this.r1.ReadOnly = true;
            this.r1.Size = new System.Drawing.Size(35, 34);
            this.r1.TabIndex = 37;
            this.r1.TabStop = false;
            this.r1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // w5
            // 
            this.w5.BackColor = System.Drawing.Color.White;
            this.w5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.w5.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.w5.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w5.Location = new System.Drawing.Point(459, 408);
            this.w5.Multiline = true;
            this.w5.Name = "w5";
            this.w5.ReadOnly = true;
            this.w5.Size = new System.Drawing.Size(35, 34);
            this.w5.TabIndex = 54;
            this.w5.TabStop = false;
            this.w5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // w8
            // 
            this.w8.BackColor = System.Drawing.Color.White;
            this.w8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.w8.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.w8.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w8.Location = new System.Drawing.Point(459, 448);
            this.w8.Multiline = true;
            this.w8.Name = "w8";
            this.w8.ReadOnly = true;
            this.w8.Size = new System.Drawing.Size(35, 34);
            this.w8.TabIndex = 53;
            this.w8.TabStop = false;
            this.w8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // w9
            // 
            this.w9.BackColor = System.Drawing.Color.White;
            this.w9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.w9.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.w9.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w9.Location = new System.Drawing.Point(500, 448);
            this.w9.Multiline = true;
            this.w9.Name = "w9";
            this.w9.ReadOnly = true;
            this.w9.Size = new System.Drawing.Size(35, 34);
            this.w9.TabIndex = 52;
            this.w9.TabStop = false;
            this.w9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // w6
            // 
            this.w6.BackColor = System.Drawing.Color.White;
            this.w6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.w6.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.w6.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w6.Location = new System.Drawing.Point(500, 408);
            this.w6.Multiline = true;
            this.w6.Name = "w6";
            this.w6.ReadOnly = true;
            this.w6.Size = new System.Drawing.Size(35, 34);
            this.w6.TabIndex = 51;
            this.w6.TabStop = false;
            this.w6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // w7
            // 
            this.w7.BackColor = System.Drawing.Color.White;
            this.w7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.w7.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.w7.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w7.Location = new System.Drawing.Point(418, 448);
            this.w7.Multiline = true;
            this.w7.Name = "w7";
            this.w7.ReadOnly = true;
            this.w7.Size = new System.Drawing.Size(35, 34);
            this.w7.TabIndex = 50;
            this.w7.TabStop = false;
            this.w7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // w4
            // 
            this.w4.BackColor = System.Drawing.Color.White;
            this.w4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.w4.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.w4.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w4.Location = new System.Drawing.Point(418, 408);
            this.w4.Multiline = true;
            this.w4.Name = "w4";
            this.w4.ReadOnly = true;
            this.w4.Size = new System.Drawing.Size(35, 34);
            this.w4.TabIndex = 49;
            this.w4.TabStop = false;
            this.w4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // w3
            // 
            this.w3.BackColor = System.Drawing.Color.White;
            this.w3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.w3.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.w3.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w3.Location = new System.Drawing.Point(500, 368);
            this.w3.Multiline = true;
            this.w3.Name = "w3";
            this.w3.ReadOnly = true;
            this.w3.Size = new System.Drawing.Size(35, 34);
            this.w3.TabIndex = 48;
            this.w3.TabStop = false;
            this.w3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // w2
            // 
            this.w2.BackColor = System.Drawing.Color.White;
            this.w2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.w2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.w2.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w2.Location = new System.Drawing.Point(459, 368);
            this.w2.Multiline = true;
            this.w2.Name = "w2";
            this.w2.ReadOnly = true;
            this.w2.Size = new System.Drawing.Size(35, 34);
            this.w2.TabIndex = 47;
            this.w2.TabStop = false;
            this.w2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // w1
            // 
            this.w1.BackColor = System.Drawing.Color.White;
            this.w1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.w1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.w1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w1.Location = new System.Drawing.Point(418, 368);
            this.w1.Multiline = true;
            this.w1.Name = "w1";
            this.w1.ReadOnly = true;
            this.w1.Size = new System.Drawing.Size(35, 34);
            this.w1.TabIndex = 46;
            this.w1.TabStop = false;
            this.w1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox_Cubo
            // 
            this.groupBox_Cubo.Controls.Add(this.w5);
            this.groupBox_Cubo.Controls.Add(this.w8);
            this.groupBox_Cubo.Controls.Add(this.w9);
            this.groupBox_Cubo.Controls.Add(this.w6);
            this.groupBox_Cubo.Controls.Add(this.w7);
            this.groupBox_Cubo.Controls.Add(this.w4);
            this.groupBox_Cubo.Controls.Add(this.w3);
            this.groupBox_Cubo.Controls.Add(this.w2);
            this.groupBox_Cubo.Controls.Add(this.w1);
            this.groupBox_Cubo.Controls.Add(this.r5);
            this.groupBox_Cubo.Controls.Add(this.r8);
            this.groupBox_Cubo.Controls.Add(this.r9);
            this.groupBox_Cubo.Controls.Add(this.r6);
            this.groupBox_Cubo.Controls.Add(this.r7);
            this.groupBox_Cubo.Controls.Add(this.r4);
            this.groupBox_Cubo.Controls.Add(this.r3);
            this.groupBox_Cubo.Controls.Add(this.r2);
            this.groupBox_Cubo.Controls.Add(this.r1);
            this.groupBox_Cubo.Controls.Add(this.g5);
            this.groupBox_Cubo.Controls.Add(this.g8);
            this.groupBox_Cubo.Controls.Add(this.g9);
            this.groupBox_Cubo.Controls.Add(this.g6);
            this.groupBox_Cubo.Controls.Add(this.g7);
            this.groupBox_Cubo.Controls.Add(this.g4);
            this.groupBox_Cubo.Controls.Add(this.g3);
            this.groupBox_Cubo.Controls.Add(this.g2);
            this.groupBox_Cubo.Controls.Add(this.g1);
            this.groupBox_Cubo.Controls.Add(this.y5);
            this.groupBox_Cubo.Controls.Add(this.y8);
            this.groupBox_Cubo.Controls.Add(this.y9);
            this.groupBox_Cubo.Controls.Add(this.y6);
            this.groupBox_Cubo.Controls.Add(this.y7);
            this.groupBox_Cubo.Controls.Add(this.y4);
            this.groupBox_Cubo.Controls.Add(this.y3);
            this.groupBox_Cubo.Controls.Add(this.y2);
            this.groupBox_Cubo.Controls.Add(this.y1);
            this.groupBox_Cubo.Controls.Add(this.o5);
            this.groupBox_Cubo.Controls.Add(this.o8);
            this.groupBox_Cubo.Controls.Add(this.o9);
            this.groupBox_Cubo.Controls.Add(this.o6);
            this.groupBox_Cubo.Controls.Add(this.o7);
            this.groupBox_Cubo.Controls.Add(this.o4);
            this.groupBox_Cubo.Controls.Add(this.o3);
            this.groupBox_Cubo.Controls.Add(this.o2);
            this.groupBox_Cubo.Controls.Add(this.o1);
            this.groupBox_Cubo.Controls.Add(this.b5);
            this.groupBox_Cubo.Controls.Add(this.b8);
            this.groupBox_Cubo.Controls.Add(this.b9);
            this.groupBox_Cubo.Controls.Add(this.b6);
            this.groupBox_Cubo.Controls.Add(this.b7);
            this.groupBox_Cubo.Controls.Add(this.b4);
            this.groupBox_Cubo.Controls.Add(this.b3);
            this.groupBox_Cubo.Controls.Add(this.b2);
            this.groupBox_Cubo.Controls.Add(this.b1);
            this.groupBox_Cubo.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_Cubo.Location = new System.Drawing.Point(396, 74);
            this.groupBox_Cubo.Name = "groupBox_Cubo";
            this.groupBox_Cubo.Size = new System.Drawing.Size(570, 600);
            this.groupBox_Cubo.TabIndex = 55;
            this.groupBox_Cubo.TabStop = false;
            this.groupBox_Cubo.Text = "Cubo de Rubik";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.ArquivoCrip);
            this.groupBox1.Controls.Add(this.GerArq);
            this.groupBox1.Controls.Add(this.Arquivo);
            this.groupBox1.Controls.Add(this.ArquivoTXT);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(988, 74);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(330, 600);
            this.groupBox1.TabIndex = 56;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Arquivo";
            // 
            // button2
            // 
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(173, 559);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(140, 32);
            this.button2.TabIndex = 59;
            this.button2.Text = "Descriptografar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // ArquivoCrip
            // 
            this.ArquivoCrip.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ArquivoCrip.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ArquivoCrip.Location = new System.Drawing.Point(18, 559);
            this.ArquivoCrip.Name = "ArquivoCrip";
            this.ArquivoCrip.Size = new System.Drawing.Size(140, 32);
            this.ArquivoCrip.TabIndex = 58;
            this.ArquivoCrip.Text = "Criptografar";
            this.ArquivoCrip.UseVisualStyleBackColor = true;
            this.ArquivoCrip.Click += new System.EventHandler(this.ArquivoCrip_Click_1);
            // 
            // GerArq
            // 
            this.GerArq.Cursor = System.Windows.Forms.Cursors.Hand;
            this.GerArq.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GerArq.Location = new System.Drawing.Point(173, 519);
            this.GerArq.Name = "GerArq";
            this.GerArq.Size = new System.Drawing.Size(140, 32);
            this.GerArq.TabIndex = 57;
            this.GerArq.Text = "Gerar Arquivo";
            this.GerArq.UseVisualStyleBackColor = true;
            this.GerArq.Click += new System.EventHandler(this.GerArq_Click);
            // 
            // ArquivoTXT
            // 
            this.ArquivoTXT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ArquivoTXT.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ArquivoTXT.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ArquivoTXT.Location = new System.Drawing.Point(6, 36);
            this.ArquivoTXT.Multiline = true;
            this.ArquivoTXT.Name = "ArquivoTXT";
            this.ArquivoTXT.Size = new System.Drawing.Size(318, 477);
            this.ArquivoTXT.TabIndex = 56;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Hora);
            this.groupBox2.Controls.Add(this.DataAtual);
            this.groupBox2.Controls.Add(this.Sec);
            this.groupBox2.Controls.Add(this.Ano);
            this.groupBox2.Controls.Add(this.Min);
            this.groupBox2.Controls.Add(this.Mes);
            this.groupBox2.Controls.Add(this.Dia);
            this.groupBox2.Controls.Add(this.lbl_Ano);
            this.groupBox2.Controls.Add(this.lbl_Mes);
            this.groupBox2.Controls.Add(this.lbl_Dia);
            this.groupBox2.Controls.Add(this.lbl_Hora);
            this.groupBox2.Controls.Add(this.lbl_Min);
            this.groupBox2.Controls.Add(this.lbl_Sec);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(44, 74);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(330, 214);
            this.groupBox2.TabIndex = 57;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Chave";
            // 
            // projeto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1350, 729);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox_Cubo);
            this.Controls.Add(this.groupBox_Dados);
            this.Name = "projeto";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Criptografia";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.groupBox_Dados.ResumeLayout(false);
            this.groupBox_Dados.PerformLayout();
            this.groupBox_Cubo.ResumeLayout(false);
            this.groupBox_Cubo.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_Dados;
        private System.Windows.Forms.Label lbl_Ano;
        private System.Windows.Forms.TextBox Ano;
        private System.Windows.Forms.Label lbl_Mes;
        private System.Windows.Forms.TextBox Mes;
        private System.Windows.Forms.Label lbl_Texto;
        private System.Windows.Forms.TextBox textoCrip;
        private System.Windows.Forms.Button btn_Criptografar;
        private System.Windows.Forms.TextBox Texto;
        private System.Windows.Forms.Label lbl_Sec;
        private System.Windows.Forms.TextBox Sec;
        private System.Windows.Forms.Label lbl_Min;
        private System.Windows.Forms.TextBox Min;
        private System.Windows.Forms.Label lbl_Hora;
        private System.Windows.Forms.TextBox Hora;
        private System.Windows.Forms.Label lbl_Dia;
        private System.Windows.Forms.TextBox Dia;
        private System.Windows.Forms.TextBox b1;
        private System.Windows.Forms.TextBox b2;
        private System.Windows.Forms.TextBox b3;
        private System.Windows.Forms.TextBox b4;
        private System.Windows.Forms.TextBox b7;
        private System.Windows.Forms.TextBox b6;
        private System.Windows.Forms.TextBox b9;
        private System.Windows.Forms.TextBox b8;
        private System.Windows.Forms.TextBox b5;
        private System.Windows.Forms.TextBox o5;
        private System.Windows.Forms.TextBox o8;
        private System.Windows.Forms.TextBox o9;
        private System.Windows.Forms.TextBox o6;
        private System.Windows.Forms.TextBox o7;
        private System.Windows.Forms.TextBox o4;
        private System.Windows.Forms.TextBox o3;
        private System.Windows.Forms.TextBox o2;
        private System.Windows.Forms.TextBox o1;
        private System.Windows.Forms.TextBox y5;
        private System.Windows.Forms.TextBox y8;
        private System.Windows.Forms.TextBox y9;
        private System.Windows.Forms.TextBox y6;
        private System.Windows.Forms.TextBox y7;
        private System.Windows.Forms.TextBox y4;
        private System.Windows.Forms.TextBox y3;
        private System.Windows.Forms.TextBox y2;
        private System.Windows.Forms.TextBox y1;
        private System.Windows.Forms.TextBox g5;
        private System.Windows.Forms.TextBox g8;
        private System.Windows.Forms.TextBox g9;
        private System.Windows.Forms.TextBox g6;
        private System.Windows.Forms.TextBox g7;
        private System.Windows.Forms.TextBox g4;
        private System.Windows.Forms.TextBox g3;
        private System.Windows.Forms.TextBox g2;
        private System.Windows.Forms.TextBox g1;
        private System.Windows.Forms.TextBox r5;
        private System.Windows.Forms.TextBox r8;
        private System.Windows.Forms.TextBox r9;
        private System.Windows.Forms.TextBox r6;
        private System.Windows.Forms.TextBox r7;
        private System.Windows.Forms.TextBox r4;
        private System.Windows.Forms.TextBox r3;
        private System.Windows.Forms.TextBox r2;
        private System.Windows.Forms.TextBox r1;
        private System.Windows.Forms.TextBox w5;
        private System.Windows.Forms.TextBox w8;
        private System.Windows.Forms.TextBox w9;
        private System.Windows.Forms.TextBox w6;
        private System.Windows.Forms.TextBox w7;
        private System.Windows.Forms.TextBox w4;
        private System.Windows.Forms.TextBox w3;
        private System.Windows.Forms.TextBox w2;
        private System.Windows.Forms.TextBox w1;
        private System.Windows.Forms.GroupBox groupBox_Cubo;
        private System.Windows.Forms.Button btn_Visualizar;
        private System.Windows.Forms.Button btn_Descriptografar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button DataAtual;
        private System.Windows.Forms.Button Arquivo;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox ArquivoTXT;
        private System.Windows.Forms.Button GerArq;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button ArquivoCrip;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}

